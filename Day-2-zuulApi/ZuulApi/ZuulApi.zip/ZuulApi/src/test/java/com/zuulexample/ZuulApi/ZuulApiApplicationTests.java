package com.zuulexample.ZuulApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZuulApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
